from django.urls import path
from app1.views import jone_ViewSet,movies_ViewSet,get_jone_ratings

from rest_framework.routers import DefaultRouter
router = DefaultRouter()
router.register('jones', jone_ViewSet, basename="jones")
router.register('movies', movies_ViewSet, basename='movies')


urlpatterns = [
        path('jones/<int:jone_id>/ratings/<str:start_date>/<str:end_date>/', get_jone_ratings, name='jone-ratings'),


]+router.urls