from rest_framework import serializers
from app1.models import joner , movies


class joner_Serializer(serializers.ModelSerializer):
    class Meta:
        model = joner
        fields = ['jone_name']
class movies_Serializer(serializers.ModelSerializer):
    class Meta:
        model = movies
        fields = ['movie_name','movie_release_date','jone_name','rating']