from django.db import models
from django.core.validators import MaxValueValidator, MinValueValidator


# Create your models here.
class joner(models.Model):
    jone_name = models.CharField(max_length=250)

class movies(models.Model):
    movie_name = models.CharField(max_length=250)
    movie_release_date = models.DateField()
    jone_name = models.ForeignKey(joner,on_delete=models.PROTECT)
    rating = models.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(5)])

