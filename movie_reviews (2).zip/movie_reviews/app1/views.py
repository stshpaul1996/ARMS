from django.shortcuts import render
from rest_framework import viewsets
from app1.models import joner,movies
from app1.serializers import joner_Serializer,movies_Serializer
# Create your views here.
from django.db.models import Avg
from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from rest_framework.decorators import api_view
from datetime import datetime
#=======================


class jone_ViewSet(viewsets.ModelViewSet):
    queryset = joner.objects.all()
    serializer_class = joner_Serializer


class movies_ViewSet(viewsets.ModelViewSet):
    queryset = movies.objects.all()
    serializer_class = movies_Serializer

#===================================
@api_view(['GET'])
def get_jone_ratings(request, jone_id, start_date, end_date):
    """
    Get average ratings for movies in a specific jone within a given time range.
    """
    try:
        start_date = datetime.strptime(start_date, "%Y-%m-%d")
        end_date = datetime.strptime(end_date, "%Y-%m-%d")
    except ValueError:
        return JsonResponse({"error": "Invalid date format. Use YYYY-MM-DD."}, status=400)

    jone = get_object_or_404(joner, pk=jone_id)
    
    # Filter movies by jone and release date within the specified range
    movies_within_range = movies.objects.filter(jone_name=jone, movie_release_date__range=(start_date, end_date))
    
    # Calculate average rating for the selected movies
    avg_rating = movies_within_range.aggregate(Avg('rating'))['rating__avg']


    # Print the result in the command prompt
    print(f"Jone: {jone.jone_name}",'==================')
    print(f"Start Date: {start_date}",'=====================')
    print(f"End Date: {end_date}",'==================')
    print(f"Average Rating: {avg_rating}",'======================')

    response_data = {
        "jone_name": jone.jone_name,
        "start_date": start_date,
        "end_date": end_date,
        "average_rating": avg_rating,
    }

    return JsonResponse(response_data)

#============================================

