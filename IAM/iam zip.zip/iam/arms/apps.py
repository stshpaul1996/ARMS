from django.apps import AppConfig


class ArmsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'arms'
